package com.suduko.sudokusolver;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class playSudoku extends AppCompatActivity {

    View root;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_sudoku);

        root =findViewById(R.id.activity_play_sudoku).getRootView();
        root.setBackgroundResource(R.drawable.gradient);
    }
}